from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = "Secret Key"

# Configures with mysqp
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
#'mysql://root:''@localhost/cmsc447project'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Creates data table
class Data(db.Model):
    county = db.Column(db.String(100), primary_key = True)
    state = db.Column(db.String(100))
    covid_inf = db.Column(db.String(100))
    vacs_complete_per = db.Column(db.String(100))
    house_med = db.Column(db.String(100))
    house_per = db.Column(db.String(100))

    def __init__(self, county, state, covid_inf, vacs_complete_per, house_med, house_per):
        self.county = county
        self.state = state
        self.covid_inf = covid_inf
        self.vacs_complete_per = vacs_complete_per
        self.house_med = house_med
        self.house_med = house_per

# Route path for all CRUD queries
@app.route('/')
def Index():
    all_data = Data.query.all()
    return render_template("index.html", county = all_data)

# Adds county
@app.route('/add', methods = ['POST'])
def add():
    if request.method == 'POST':
        county = request.form['county']
        state = request.form['state']
        covid_inf = request.form['covid_inf']
        vacs_complete_per = request.form['vacs_complete_per']
        house_med = request.form['house_med']
        house_per = request.form['house_per']
        my_data = Data(county, state, covid_inf, vacs_complete_per, house_med, house_per)
        db.session.add(my_data)
        db.session.commit()
        return redirect(url_for('Index'))

# Updates county
@app.route('/update', methods = ['GET', 'POST'])
def update():
    if request.method == 'POST':
        my_data = Data.query.get(request.form.get('county'))
        #my_data.state = request.form['state']
        my_data.covid_inf = request.form['covid_inf']
        my_data.vacs_complete_per = request.form['vacs_complete_per']
        my_data.house_med = request.form['house_med']
        my_data.house_per = request.form['house_per']
        db.session.commit()
        return redirect(url_for('Index'))

# Deletes county
@app.route('/delete/<county>/', methods = ['GET', 'POST'])
def delete(county):
    my_data = Data.query.get(county)
    db.session.delete(my_data)
    db.session.commit()
    return redirect(url_for('Index'))

if __name__ == "__main__":
    app.run(debug=True)